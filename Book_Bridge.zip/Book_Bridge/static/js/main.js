// Book Bridge - small UI helpers (the server still validates everything)
document.addEventListener("DOMContentLoaded", function () {
  // Bootstrap-style client-side validation
  document.querySelectorAll("form.needs-validation").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      var pw = form.querySelector("#password"), pw2 = form.querySelector("#confirm_password");
      if (pw && pw2) {
        pw2.setCustomValidity(pw.value !== pw2.value ? "Passwords do not match" : "");
      }
      if (!form.checkValidity()) { e.preventDefault(); e.stopPropagation(); }
      form.classList.add("was-validated");
    });
  });

  // Image upload: type/size check + preview
  var input = document.getElementById("image");
  if (input) {
    input.addEventListener("change", function () {
      var preview = document.getElementById("imagePreview"), err = document.getElementById("imageError");
      var f = input.files[0];
      if (err) err.textContent = "";
      if (!f) { if (preview) preview.classList.add("d-none"); return; }
      if (!/^image\/(png|jpe?g|webp)$/.test(f.type)) {
        if (err) err.textContent = "Please choose a PNG, JPG or WEBP image.";
        input.value = ""; return;
      }
      if (f.size > 5 * 1024 * 1024) {
        if (err) err.textContent = "Image is too large (maximum 5 MB).";
        input.value = ""; return;
      }
      if (preview) { preview.src = URL.createObjectURL(f); preview.classList.remove("d-none"); }
    });
  }

  // Confirm dangerous actions
  document.querySelectorAll("form[data-confirm]").forEach(function (form) {
    form.addEventListener("submit", function (e) {
      if (!window.confirm(form.getAttribute("data-confirm"))) e.preventDefault();
    });
  });

  // Auto-dismiss success alerts
  document.querySelectorAll(".alert-success").forEach(function (a) {
    setTimeout(function () {
      if (window.bootstrap) bootstrap.Alert.getOrCreateInstance(a).close();
    }, 6000);
  });
});
